# CoD Warzone - Char Selector (React.JS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Delos_343/pen/PoJZNXw](https://codepen.io/Delos_343/pen/PoJZNXw).

Uses react and CSS animations to recreate the slot machine mini game from Super Mario Bros. 3.

In hindsight,  this was a really weird tool for this job. But I learned a bit more about React, so I have that going for me.

Some of the CSS is wonky as hell.

Also, I am not claiming copyright to a game that was released when I was a toddler. It's just a tribute. Go easy, Nintendo.
